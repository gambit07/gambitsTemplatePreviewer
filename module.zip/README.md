# gambitsTemplatePreviewer
<p><b>To support my continued work on this module! Join my Patreon at https://www.patreon.com/GambitsLounge or donate on Kofi at https://ko-fi.com/gambit07</b></p>
<p><b>Join my Discord! If you have any questions, feature requests, or just generally want to chat feel free to join Gambit's Lounge: https://discord.gg/YNquuTzcJB</b></p>
<p>Have your players ever wished they could preview their templates off their turn? If so, this tool may be for you! This module adds a tool to the Token controls menu for previewing template placements. It supports previewing a template placement for any template-targeting items you own, or previewing generic templates with configurable size.</p>
<p>&nbsp;</p>
<p>https://github.com/user-attachments/assets/653088a1-0232-4386-8c4a-aa9c8685eaf9</p>
